import unittest

class Apptesting(unittest.TestCase):


    @unittest.SkipTest #decorater
    def test_search(self):
        print("This is earch test")

    @unittest.skip("I am skipping this test method bcos it is not yet ready")
    def test_advancedsearch(self):
        print("Thi is adv earch method")

    @unittest.skipIf(1==1,"Number are not Equals To One")
    def test_prepaidrecharge(self):
        print("This is pre-paid recharge")

    def test_postpaidreacharge(self):
        print("This is post-paid reacharge")

    def test_loginbygmail(self):
        print("This is login by email")

    def test_loginbytwitter(self):
        print("This is login by twitter")

if __name__=="__main__":
    unittest.main()
