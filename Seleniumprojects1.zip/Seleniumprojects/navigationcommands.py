from  selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time

driver=webdriver.Firefox(executable_path="D:\python\selenuim\geckodriver-v0.28.0-win64(firefox)\geckodriver.exe")
driver.get("http://localhost:8000")
print(driver.title) #Title of the page

driver.get("http://127.0.0.1:8000/admin/")
time.sleep(10)
print(driver.title) #Title of the page
driver.back()
time.sleep(10)
print(driver.title)
driver.forward()
time.sleep(10)
print(driver.title)
