import unittest

class Test(unittest.TestCase):
    def test_firstTest(self):
        print("this is my first unite test case")

if __name__=="__main__":
    unittest.main()