import unittest
#setup method, teardown

def setUpModule():#will be execute before executing any class or any method present in the test class
    print("SetUpModule")

def tearDownModule():#will be execute after executing any class or any method present in the test class
    print("TearDownModule")

class AppTesting(unittest.TestCase):
    #setup method setup class
    @classmethod
    def setUp(self): #Execute before all test methods
        print("This is login test, set Up")

    #TearTest method TearTest Class
    @classmethod
    def tearDown(self): #execute after all test methods
        print("This is logout test, tear Down")

    @classmethod
    def setUpClass(cls): #Execute once then when the class started
        print("open applications setup class")

    @classmethod
    def tearDownClass(cls): #Execute once after the class completed
        print("close application tear Down class")


    def test_search(self):
        print("This is search test")

    def test_advancedsearch(self):
        print("This is advanced search test")

    def test_prepaidRecharge(self):
        print("This is prepaid Recharge test")

    def test_postpaidRecharge(self):
        print("This is post paidRecharge test")

if __name__=="__main__":
    unittest.main()