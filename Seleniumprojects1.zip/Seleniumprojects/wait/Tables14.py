from selenium import webdriver
from selenium.webdriver.common.by import By

driver=webdriver.Firefox(executable_path="D:\python\selenuim\geckodriver-v0.28.0-win64(firefox)\geckodriver.exe")

driver.get("http://localhost:8000/orders")#my web table

#rows=(driver.find_elements_by_xpath("/html/body/table/tbody/tr"))#count number of table
#cols=len(driver.find_elements_by_xpath("/html/body/table/tbody/tr[1]/th"))#count number of columns
rows=(driver.find_elements_by_xpath("/html/body/div/div/table/tbody/tr"))#count number of table
cols=len(driver.find_elements_by_xpath("/html/body/div/div/table/tbody/tr[1]/th"))#count number of columns

print(rows)
print(cols)

#print("product"+"  "+"Article"+" "+"Price")
print("Sno"+"  "+"Image"+" "+"Product"+" "+"Price"+"  "+"Date"+"  "+"Quantity"+"  "+"Total"+"  "+"Status")

for r in range[2,rows+1]:
    for c in range[1,cols+1]:
        value=driver.find_elements_by_xpath("/html/body/div/div/table/tbody/tr["+str(r)+"]/td["+str(c)+"]").text
        print(value,end='  ')#print 0001 10
    print()
    #3:07:10
