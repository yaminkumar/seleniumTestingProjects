from selenium import webdriver
from selenium.webdriver.common.by import By
import time

driver=webdriver.Firefox(executable_path="D:\python\selenuim\geckodriver-v0.28.0-win64(firefox)\geckodriver.exe")

driver.get("http://localhost:8000/signup")

driver.find_element_by_xpath("").click()#altert option select xpath

time.sleep(5)

#driver.switch_to_alert().accept() #close alert window using of button

driver.switch_to_alert().desmiss() #close alert window using cansel of button
