from selenium import webdriver
from selenium.webdriver.common.by import By

driver=webdriver.Firefox(executable_path="D:\python\selenuim\geckodriver-v0.28.0-win64(firefox)\geckodriver.exe")

driver.get("http://localhost:8000")

links=driver.find_elements(By.TAG_NAME,"a")

print("Number of links present:",len(links)) # print how many links presenting in a page

for link in links:
    print(link.text)

#clinking on the link
#driver.find_element(By.LINK_TEXT,"Signup ").click()

driver.find_element(By.PARTIAL_LINK_TEXT,"Sign").click()

