from selenium import webdriver
from selenium.webdriver.common.by import By

driver=webdriver.Firefox(executable_path="D:\python\selenuim\geckodriver-v0.28.0-win64(firefox)\geckodriver.exe")

driver.get("http://localhost:8000/signup")

driver.find_elements_by_xpath("//*[@id='navbarSupportedContent']/ul[2]/li[2]/a").clear()

#carent w.indow handle
print(driver.current_window_handle) #parents window

handles=driver.window_handles #returns all the handle value of open window
for handle in handles:
    driver.switch_to.window(handle)
    print(driver.title)
    if driver.title=="Frames & windows":
        driver.close() #close only parents browser

driver.quit()



