from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select

driver=webdriver.Firefox(executable_path="D:\python\selenuim\geckodriver-v0.28.0-win64(firefox)\geckodriver.exe")

driver.get("http://localhost:8000/signup")

element=driver.find_element_by_id("RESULT_RadioButton-7")
drp=Select(element)

#select by visible text
drp.select_by_visible_text('Morning') #morning

#select by index
drp.select_by_index(2) #afternoon
#select by value
drp.select_by_value("Radio-2")#evining

#Count number of options
print(len(drp.options))

#Capture all the options and print them as output
all_options=drp.options
for option in all_options:
    print(option.text)