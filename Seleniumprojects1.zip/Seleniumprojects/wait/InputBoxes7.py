from selenium import webdriver
from selenium.webdriver.common.by import By

driver=webdriver.Firefox(executable_path="D:\python\selenuim\geckodriver-v0.28.0-win64(firefox)\geckodriver.exe")

driver.get("http://localhost:8000/signup")

#how to find how many inputboxes present in web page

#inputboxes=driver.find_elements(By.CLASS_NAME,'form-control')#class="form-control"more then variable
#print(len(inputboxes))

#status=driver.find_element(By.ID,'firstname').is_displayed()
#print("Displayed or not: ",status) #true/false
#status=driver.find_element(By.ID,'lastname').is_enabled()
#print("Enabled or not ",status)

#driver.find_element(By.ID,'form-control form-control-sm').send_keys('Syam')
#driver.find_element(By.ID,'form-control form-control-sm').send_keys('kumar')

status=driver.find_element_by_name("firstname").is_displayed()
print("Displayed or not: ",status) #true/false
status=driver.find_element_by_name("lastname").is_enabled()
print("Enabled or not ",status)

driver.find_element_by_name("firstname").send_keys("syam")
driver.find_element_by_name("lastname").send_keys("kumar")

#driver.find_element_by_id("form-control form-control-sm").send_keys("88u878787")
driver.find_element_by_name("phone").send_keys("7509788213")
driver.find_element_by_name("email").send_keys("kumar@gmail.com")
driver.find_element_by_name("password").send_keys("123456")
driver.find_elements(By.CLASS_NAME,'btn btn-sm btn-info')#class="form-control"more then variable : 145:45
