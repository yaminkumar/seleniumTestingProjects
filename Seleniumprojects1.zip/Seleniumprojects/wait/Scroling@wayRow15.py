from selenium import webdriver
from selenium.webdriver.common.by import By

driver=webdriver.Firefox(executable_path="D:\python\selenuim\geckodriver-v0.28.0-win64(firefox)\geckodriver.exe")

driver.get("htt://www.countries-ofthe-world.com/flags-of-the-world.html")#my web table

driver.maximize_window()#maximize the window size

#1.scroll down page by pixel
#driver.execute_script("window.scrollBy(0,1000)","")

#2.Scroll down page till tjhe element is visible

#flag=driver.find_elements_by_xpath("//*[@='content']/div[2]/div[2]/table[1]/tbody/tr[86]/td[1]/img")
#driver.execute_script("arguments[0].scrollIntoView();",flag)

driver.execute_script("window.scrollBy(0,document.body.scrollHieght)")