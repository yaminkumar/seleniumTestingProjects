from selenium import webdriver
from selenium.webdriver.common.by import By
import time

driver=webdriver.Firefox(executable_path="D:\python\selenuim\geckodriver-v0.28.0-win64(firefox)\geckodriver.exe")

driver.get("http://seleniumhq.github.io/selenium/doc/api/java/index.html")

driver.switch_to_frame("packageListFrame") #first frame
driver.find_element_by_link_text("org.openqa.selenium").click()

time.sleep(5)
driver.switch_to.default_content()

driver.switch_to_frame("packageFrame") #second frame

driver.find_element_by_link_text("WebDriver").click()
time.sleep(5)
driver.switch_to.default_content()
time.sleep(5)
driver.switch_to_frame("classFrame")#third frame
driver.find_element_by_xpath("/html/body/div[1]/ul/li[5]").click()

#2:35:31
