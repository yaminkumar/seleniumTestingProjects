from selenium import webdriver
#emlicite wait

driver=webdriver.Firefox(executable_path="D:\python\selenuim\geckodriver-v0.28.0-win64(firefox)\geckodriver.exe")
driver.get("http://localhost:8000/admin/") #opening url takes some time

driver.implicitly_wait(10) #seconds

assert 'welcome: admin Tours' in driver.title

driver.find_element_by_name("username").send_keys("admin")
driver.find_element_by_name("password").send_keys("123")

#driver.find_element_by_name("//*[@id='login-form']/div[3]/input").click()
driver.find_element_by_xpath("//*[@id='login-form']/div[3]/input").click()