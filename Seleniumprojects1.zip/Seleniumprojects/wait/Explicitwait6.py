from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
from  selenium.webdriver.support import expected_conditions as EC
from  selenium.webdriver.support.ui import WebDriverWait
#emlicite wait
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait

driver=webdriver.Firefox(executable_path="D:\python\selenuim\geckodriver-v0.28.0-win64(firefox)\geckodriver.exe")
driver.implicitly_wait(10)
driver.maximize_window()

driver.get("http://localhost:8000/cart") #opening url takes some time

#driver.find_element_by_id("result_list").click()
#driver.find_element_by_id("result_list").click()#at button using your id="result_list"

driver.find_element(By.XPATH,"//*[@id='navbarSupportedContent']/ul[2]/li[1]/a").click() #Flights button
#driver.find_element(By.ID,"flight-origin-tab-hp-flight").send_keys("SFO") #origin
driver.find_element(By.XPATH,"//*[@id='exampleModal']/div/div/div[2]/div/form/div[1]/input").send_keys("Mungely")
time.sleep(2) #from python
#driver.find_element(By.ID,"exampleModal").clear()
#driver.find_element(By.ID,"flight-destination-hp-flight").send_keys("NYC")#destination
driver.find_element(By.XPATH,"//*[@id='exampleModal']/div/div/div[2]/div/form/div[2]/input").send_keys("7509788213")#origen
#driver.find_element(By.ID,"exampleModal").send_keys("12/11/2020")#origen
#driver.find_element(By.ID,"exampleModal").send_keys("7509788213")#origen
driver.find_element(By.XPATH,"//*[@id='exampleModal']/div/div/div[2]/div/form/input[2]").click()

#explicit waits
#driver.find_element(By.XPATHE,"").click()
#wait=WebDriverWait(driver,10,)#search button
#element=wait.until(EC.element_to_be_clickable(By.XPATH,""))
#element.click()
time.sleep(5)
driver.quit()