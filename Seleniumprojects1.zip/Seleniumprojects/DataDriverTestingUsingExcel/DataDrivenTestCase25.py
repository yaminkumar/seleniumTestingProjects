import XLUtils24
from selenium import webdriver

driver=webdriver.Firefox(executable_path="D:\python\selenuim\geckodriver-v0.28.0-win64(firefox)\geckodriver.exe")

driver.get("http://127.0.0.1:8000/admin/")
driver.maximize_window()

path="D:\python\Login1.xlsx"

rows=XLUtils24.getRowCount(path,"Sheet1")

for r in range(2,rows+1):
    username=XLUtils24.readData(path,"Sheet1",r,1)
    password=XLUtils24.readData(path,"Sheet1",r,2)

    driver.find_element_by_id("id_username").send_keys(username)
    driver.find_element_by_id("id_password").send_keys(password)
   # driver.find_element_by_name("Log in").click()
    driver.find_element_by_xpath("//*[@id='login-form']/div[3]/input").click()

    if driver.title=="Find a admin: admin:":
        print(("test is passed"))
        XLUtils24.writeData(path,"sheet1",r,3,"test passed")
    else:
        print("test failed")
        XLUtils24.writeData(path,"sheet1",r,3,"test failed")

    driver.find_element_by_xpath("/html/body/div/div[1]/div[2]/a[3]").click()
    driver.find_element_by_xpath("/html/body/div/div[3]/div/div[1]/p[2]/a").click()

#5:05:31