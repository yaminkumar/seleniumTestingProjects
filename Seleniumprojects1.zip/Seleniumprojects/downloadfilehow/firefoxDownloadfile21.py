from selenium import webdriver

from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

#download my expected locations #firefoxe browdser river
fp=webdriver.FirefoxProfile()

fp.set_preference("browser.helperApps.neverAsk.saveToDisk", "text/plain,application/pdf") #Mine type
fp.set_preference("browser.download.manager.showwhenStarting",False)
fp.set_preference("browser.download.dir","c:\Downloadedfile")
fp.set_preference("browser.download.folderList",2)
fp.set_preference("pdfjs.disabled",True)

driver=webdriver.Firefox(executable_path="D:\python\selenuim\geckodriver-v0.28.0-win64(firefox)\geckodriver.exe", firefox_options=fp)
driver.get("http://localhost:8000/admin/")#my web table
#http://demo.automationtesting.in/FileDownload.html

#firfoxe browser 4:16:20

driver.maximize_window()

#download text file
driver.find_element_by_id("textbox").senf_keys("testng download text file")
driver.find_element_by_id("createtxt").click()#genrate file button

driver.find_element_by_id("link-to-download").click() #donload link

#pdf File downloading
driver.find_element_by_id("pdfbox").send_click("testing download")#
driver.find_element_by_id("createPdf").click()
driver.find_element_by_id("pdf-link-to download").click()



#driver.close()
