from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

driver=webdriver.Firefox(executable_path="D:\python\selenuim\geckodriver-v0.28.0-win64(firefox)\geckodriver.exe")

driver.get("http://localhost:8000/admin/login/?next=/admin/")#my web table
#"http://testautomationpractice.blogspot.com/"
driver.maximize_window() #maximize the page

element=driver.find_elements_by_xpath("")
#//*[@id='HTML10']/div[1]/button
actions=ActionChains(driver)

actions.double_click(element).perform()#Double click on button

