from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys


driver=webdriver.Firefox(executable_path="D:\python\selenuim\geckodriver-v0.28.0-win64(firefox)\geckodriver.exe")

driver.get("http://localhost:8000/admin/login/?next=/admin/")#my web table

driver.find_elements_by_xpath("/html/body/div/div/div/form/div[2]/input").send_key("yamin@gmail.com")
driver.find_elements_by_xpath("/html/body/div/div/div/form/div[3]/input").send_key("123456")
driver.find_elements_by_xpath("/html/body/div/div/div/form/div[4]/input").click()

#driver.find_elements_by_xpath("//*[@id='id_username']").send_key("admin")
#driver.find_elements_by_xpath("//*[@id='id_password']").send_key("123")
#driver.find_elements_by_xpath("//*[@id='login-form']/div[3]/input").click()

admin=driver.find_elements_by_xpath("//*[@id='nav-sidebar']/div[1]/table/tbody/tr[2]/th/a")
usermgnt=driver.find_elements_by_xpath("//*[@id='nav-sidebar']/div[1]/table/tbody/tr[1]/th/a")
users=driver.find_elements_by_xpath("//*[@id='result_list']/thead/tr/th[2]/div[2]/a")


actions=ActionChains(driver)
actions.move_to_element(admin).move_to_element(usermgnt).move_to_element(users).click().perform()
