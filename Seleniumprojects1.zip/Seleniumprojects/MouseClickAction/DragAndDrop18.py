from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

driver=webdriver.Firefox(executable_path="D:\python\selenuim\geckodriver-v0.28.0-win64(firefox)\geckodriver.exe")

driver.get("http://localhost:8000/admin/login/?next=/admin/")#my web table
#http://www.dhtmlgoofies.com/scripts/drag-drop-custom/demo-drag-drop-3.html

driver.maximize_window()

source_element=driver.find_elements_by_xpath("")
#//*[@='box6']
target_element=driver.find_elements_by_xpath("")
#//*[@='box106']
actions=ActionChains(driver)

actions.drag_and_drop(source_element,target_element).perform()#drag and drop action
