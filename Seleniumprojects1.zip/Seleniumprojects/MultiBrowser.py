from selenium import webdriver
from selenium.webdriver.common.keys import Keys

driver=webdriver.Firefox(executable_path="D:\python\selenuim\geckodriver-v0.28.0-win64(firefox)\geckodriver.exe")
#driver=webdriver.Chrome(executable_path="D:\python\selenuim\chromedrivers_win32\chromedriver.exe")
driver.get("http://localhost:8000/")
print(driver.title) #Title of the page
print(driver.current_url) # returns the url of the page
#driver.close()
driver=webdriver.Ie(executable_path="D:\python\selenuim\IEDriverServers_Win32_2.53.1\IEDriverServer.exe")
driver.get("http://localhost:8000/")
print(driver.title) #Title of the page
print(driver.current_url) # returns the url of the page
#print(driver.page_source) #returns the html code
#driver.close() #close the browser