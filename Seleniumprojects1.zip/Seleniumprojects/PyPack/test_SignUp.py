import pytest


@pytest.yield_fixture()
def setUp():
    print("Opening URL to Signup")
    yield
    print("Closing browser after signup")

def test_signupbyemail(setUp):
    print("This is signup by email test")

def test_signbyfacebook(setUp):
    print("This is signup by facebook test")