# assertIn & assertNotIn
import unittest
#from selenium import webdriver


class Test(unittest.TestCase):
    def testName(self):
        list={"python", "selenium", "java"}
        #self.assertIn("python",list)#pass
        #self.assertIn("ruby", list)#fail
        #self.assertNotIn("python", list)#fail
        self.assertNotIn("ruby", list)#pass
        #driver = webdriver.Firefox(executable_path="D:\python\selenuim\geckodriver-v0.28.0-win64(firefox)\geckodriver.exe")

if __name__=="__main__":
    unittest.main()