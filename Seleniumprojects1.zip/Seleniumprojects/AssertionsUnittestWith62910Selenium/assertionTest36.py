#assertTsNone & assertIsNotNone
#butlar variable

import unittest
from selenium import webdriver

class Test(unittest.TestCase):
    def testName(self):
        driver = webdriver.Firefox(executable_path="D:\python\selenuim\geckodriver-v0.28.0-win64(firefox)\geckodriver.exe")
        #driver = None
        #self.assertIsNone(driver)
        self.assertIsNotNone(driver)
        #6:56:56