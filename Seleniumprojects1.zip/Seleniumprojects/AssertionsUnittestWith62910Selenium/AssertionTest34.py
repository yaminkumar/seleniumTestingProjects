import unittest
from selenium import webdriver

class Test(unittest.TestCase):
    def testName(self):
        driver=webdriver.Firefox(executable_path="D:\python\selenuim\geckodriver-v0.28.0-win64(firefox)\geckodriver.exe")
        driver.get("http://www.google.com/")
        titleOfWebPage=driver.title
        #assertEqual
        #self.assertEqual("Google12",titleOfWebPage,"web title are not same")
        self.assertNotEqual("Google123",titleOfWebPage)

if __name__=="__main__":
    unittest.main()
