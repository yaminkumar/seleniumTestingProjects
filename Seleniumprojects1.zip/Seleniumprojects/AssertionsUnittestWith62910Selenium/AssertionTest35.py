#assertTrue & assertFalse
import unittest
from selenium import webdriver

class Test(unittest.TestCase):
    def testName(self):
        driver = webdriver.Firefox(executable_path="D:\python\selenuim\geckodriver-v0.28.0-win64(firefox)\geckodriver.exe")
        driver.get("http://www.google.com/")
        titleofWebPage=driver.title

        self.assertTrue(titleofWebPage == "Google")
        #self.assertFalse(titleofWebPage == "Google")

#6:47:34
if __name__=="__main__":
    unittest.main()