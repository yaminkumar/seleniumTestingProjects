from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

driver=webdriver.Firefox(executable_path="D:\python\selenuim\geckodriver-v0.28.0-win64(firefox)\geckodriver.exe")

driver.get("http://localhost:8000/admin/login/?next=/admin/")#my web table
#http://testautomationpractice.blogspot.com

driver.maximize_window()

driver.switch_to_frame(0)

driver.find_element_by_id("RESULT_FILEUpload-11").send_key("c://seleniumPractice/Fruites/inputfiles/apple.jpg")



