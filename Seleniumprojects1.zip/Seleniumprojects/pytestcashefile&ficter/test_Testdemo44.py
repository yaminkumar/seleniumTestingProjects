import pytest

def testMethod1():
    print("This is test method44")

def testMethod2():
    print("This is test Method44")
# pytest install
#pytest terminal enter
#pytest -v -s terminal enter
#pytest -v -s test_Testdemo.py terminal enter
