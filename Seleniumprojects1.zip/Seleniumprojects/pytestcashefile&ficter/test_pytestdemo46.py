import pytest

@pytest.yield_fixture()
def setup():
    print("One before every method46")
    yield
    print("One after every method46")

def testMethod1(setup):
    print("This is test1 method46")

def testMethod2(setup):
    print("This is test2 method46")

