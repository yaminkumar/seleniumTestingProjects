import pytest

@pytest.fixture()
def setup():
    print("One before every method45")

def testmethod1(setup):
    print("This s test method45")

def testmethod2():
    print("This is test method45")
#def testmethod2(setup):
#    print("This is test method2")


#pytest -v -s test_pytestdemo45.py enter terminal
#pytest -v -s enter terminal