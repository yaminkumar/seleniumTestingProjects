import unittest

class PaymentReturnsTest(unittest.TestCase):
    def test_paymentreturnbybank(self):
        print("This is payment returns by bank test")
        self.assertTrue(True)

if __name__=="__main__":
    unittest.main()

