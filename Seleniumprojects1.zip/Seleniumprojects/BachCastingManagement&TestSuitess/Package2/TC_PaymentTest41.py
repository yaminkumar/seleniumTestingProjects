import unittest

class Paymentindollor(unittest.TestCase):
    def test_paymentbyEmail(self):
        print("This is payment by dollor test")
        self.assertTrue(True)

    def test_paymentinrupees(self):
        print("This is payment by rupees test")
        self.assertTrue(True)

if __name__=="__main__":
    unittest.main()

