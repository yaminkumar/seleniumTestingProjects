import unittest
from package1.TC_LoginTest39 import LoginTest
from package1.TC_SignupTest40 import SignTest

from Package2.TC_PaymentsTest42 import PaymentTest
from Package2.TC_PaymentTest41 import PaymentReturnsTest

#Get all tests from loginTest,singUpTest,PaymentTest and PaymentReturnsTest
tc1=unittest.TestLoader().loadTestsFromTestCase(LoginTest)
tc2=unittest.TestLoader().loadTestsFromTestCase(SignTest)
tc3=unittest.TestLoader().loadTestsFromTestCase(PaymentTest)
tc4=unittest.TestLoader().loadTestsFromTestCase(PaymentReturnsTest)

#create test suites
sanityTestSuite=unittest.TestSuite(tc1,tc2) #sanity test suite
functionTestSuite=unittest.TestSuite(tc3,tc4) #functional test suite
masterTestSuite=unittest.TestSuite(tc1,tc2,tc3,tc4) #Master test suite
#verbosity=2
unittest.TextTestRunner(verbosity=2).run(masterTestSuite)

