import logging

#logging.basicConfig(filename="D://screenshort//test.log")
logging.basicConfig(filename="D://screenshort//test.log",
                    format='%(asctime)s: %(levelname)s: %(message)s',
                    level=logging.DEBUG
                    )

logging.debug("this is debug message")
logging.warning("this is warning message")

logging.info("this is info message")
logging.error("this is error message")
logging.critical("this is critical message")