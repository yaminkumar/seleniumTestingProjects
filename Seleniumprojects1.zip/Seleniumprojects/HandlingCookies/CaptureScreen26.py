from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time

driver=webdriver.Firefox(executable_path="D:\python\selenuim\geckodriver-v0.28.0-win64(firefox)\geckodriver.exe")
#driver=webdriver.Chrome(executable_path="D:\python\selenuim\chromedrivers_win32\chromedriver.exe")
driver.get("http://localhost:8000/")

#driver.save_screenshot("D:\screenshort\homPage.png")

#driver.get_screenshot_as_file("D:\screenshort\homPage2.jpg")
driver.get_screenshot_as_file("D:\screenshort\homP2.png")
