import logging

#logging.basicConfig(filename="D://screenshort//test.log")
logging.basicConfig(filename="D://screenshort//etest.log",
                    format='%(asctime)s: %(levelname)s: %(message)s',
                    datefmt='%m/%d/%Y %I:%M:%S')
logger=logging.getLogger()
logger.setLevel(logging.DEBUG)

logger.debug("this is debug message")
logger.warning("this is warning message")

logger.info("this is info message")
logger.error("this is error message")
logger.critical("this is critical message")