from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time

driver=webdriver.Firefox(executable_path="D:\python\selenuim\geckodriver-v0.28.0-win64(firefox)\geckodriver.exe")
#driver=webdriver.Chrome(executable_path="D:\python\selenuim\chromedrivers_win32\chromedriver.exe")
driver.get("http://www.amazon.in/")

#Capture all teh cookies created by browser
cookies=driver.get_cookies()
print(len(cookies))#print number of cookies hase been cookies
print(cookies) #print all the ciikies pairs

#Adding new cookie to the brower
cookie={'name':'Mycookie', 'value':'1234567'}
driver.add_cookie(cookie)

cookies=driver.get_cookies()
print(len(cookies))#print number of cookies after new cookies
print(cookies) #print all the ciikies pairs


#deleting  the cookies
driver.delete_cookies('Mycookie')
time.sleep(3)
cookies=driver.get_cookies()
print(len(cookies))#print number of cookies after deleting the cookie

driver.delete_all_cookies('Mycookie')
cookies=driver.get_cookies() #capture all
print(len(cookies))#print number of cookies after deleting the cookie

print(cookies) #print all the ciikies pairs

