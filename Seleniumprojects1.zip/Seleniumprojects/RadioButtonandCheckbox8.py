from selenium import webdriver
from selenium.webdriver.common.by import By

driver=webdriver.Firefox(executable_path="D:\python\selenuim\geckodriver-v0.28.0-win64(firefox)\geckodriver.exe")

driver.get("http://localhost:8000/signup")

#working with the radio button

status=driver.find_element_by_id("RESULT_RadioButton-8_0").is_selected() #true/false
print(status)

driver.find_element_by_id("RESULT_RadioButton-8_0").click()#select radio button

status=driver.find_element_by_id("RESULT_RadioButton-8_0").is_selected() #true/false
print(status)

#working with check boxes
driver.find_element_by_id("RESULT_RadioButton-9_0").click() #sunday
driver.find_element_by_id("RESULT_RadioButton-9_6").click() #satarday

status=driver.find_element_by_id("RESULT_RadioButton-9_0").is_selected() #true/false
print(status)